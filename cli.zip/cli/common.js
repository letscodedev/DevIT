const window = require("./webcrypto/lib")


function bytesToHexString(bytes) {
    if (!bytes)
        return null;

    bytes = new Uint8Array(bytes);
    var hexBytes = [];

    for (var i = 0; i < bytes.length; ++i) {
        var byteString = bytes[i].toString(16);
        if (byteString.length < 2)
            byteString = "0" + byteString;
        hexBytes.push(byteString);
    }

    return hexBytes.join("");
}

function bytesToASCIIString(bytes) {
    return String.fromCharCode.apply(null, new Uint8Array(bytes));
}

function hexStringToUint8Array(hexString) {
    if (hexString.length % 2 != 0)
        throw "Invalid hexString";
    var arrayBuffer = new Uint8Array(hexString.length / 2);

    for (var i = 0; i < hexString.length; i += 2) {
        var byteValue = parseInt(hexString.substr(i, 2), 16);
        if (byteValue == NaN)
            throw "Invalid hexString";
        arrayBuffer[i / 2] = byteValue;
    }

    return arrayBuffer;
}

function asciiToUint8Array(str) {
    var chars = [];
    for (var i = 0; i < str.length; ++i)
        chars.push(str.charCodeAt(i));
    return new Uint8Array(chars);
}



async function encrypt(message, k) {

    let key = await window.crypto.subtle.importKey(
        "jwk",
        {
            kty: "oct",
            k: k,
            alg: "A256GCM",
            ext: true,
        },
        {
            name: "AES-GCM",
        },
        false,
        ["encrypt", "decrypt"]
    )
    let iv = new Uint8Array(211, 61, 206, 170, 124, 121, 64, 71, 188, 29, 229, 116)

    let ciphertext = await window.crypto.subtle.encrypt(
        {
            name: "AES-GCM",
            iv: iv
        },
        key,
        asciiToUint8Array(message)
    );

    return bytesToHexString(ciphertext)
}

async function decrypt(ciphertext, k) {

    let key = await window.crypto.subtle.importKey(
        "jwk",
        {
            kty: "oct",
            k: k,
            alg: "A256GCM",
            ext: true,
        },
        {
            name: "AES-GCM",
        },
        false,
        ["encrypt", "decrypt"]
    )
    let iv = new Uint8Array(211, 61, 206, 170, 124, 121, 64, 71, 188, 29, 229, 116)

    let decrypted = await window.crypto.subtle.decrypt(
        {
            name: "AES-GCM",
            iv: iv
        },
        key,
        hexStringToUint8Array(ciphertext)
    );

    return bytesToASCIIString(decrypted)
}

async function checksum(data) {
    const digest = await window.crypto.subtle.digest("SHA-512", asciiToUint8Array(data));
    return bytesToHexString(digest)
}

module.exports = {
    decrypt,
    encrypt,
    checksum
};