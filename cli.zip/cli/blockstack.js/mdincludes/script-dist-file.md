```html
<script src="https://unpkg.com/blockstack@19.4.0-beta.1/dist/blockstack.js" integrity="sha384-SB5ZTUxSxlrMk3QBbqtewpVzllKVRD3JeT5RuZ3Tj4/1MuXaMphMCFCz1ht2qG80" crossorigin="anonymous"></script>
```