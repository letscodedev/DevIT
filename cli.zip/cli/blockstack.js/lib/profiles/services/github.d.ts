import { Service, CheerioModuleType } from './service';
import { AccountProofInfo } from '../profileProofs';
declare class Github extends Service {
    getBaseUrls(): string[];
    normalizeUrl(_proof: AccountProofInfo): string;
    getProofUrl(proof: AccountProofInfo): string;
    getProofStatement(searchText: string, _cheerio: CheerioModuleType): string;
}
export { Github };
