import { AccountProofInfo } from '../profileProofs';
export declare type CheerioModuleType = typeof import('cheerio');
/**
 * @ignore
 */
export declare abstract class Service {
    validateProof(proof: AccountProofInfo, ownerAddress: string, cheerio: CheerioModuleType, name?: string): Promise<AccountProofInfo>;
    shouldValidateIdentityInBody(): boolean;
    prefixScheme(proofUrl: string): string;
    getProofIdentity(searchText: string, _cheerio: CheerioModuleType): string;
    abstract getProofUrl(proof: AccountProofInfo): string;
    abstract getProofStatement(searchText: string, cheerio: CheerioModuleType): string;
    abstract normalizeUrl(proof: AccountProofInfo): string;
}
