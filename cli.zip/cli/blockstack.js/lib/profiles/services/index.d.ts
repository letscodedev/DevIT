import { Service } from './service';
/** @ignore */
export declare const profileServices: {
    [serviceName: string]: Service;
};
