import { Service, CheerioModuleType } from './service';
import { AccountProofInfo } from '../profileProofs';
declare class Facebook extends Service {
    getProofUrl(proof: AccountProofInfo): string;
    normalizeUrl(proof: AccountProofInfo): string;
    getProofStatement(searchText: string, cheerio: CheerioModuleType): string;
    getBaseUrls(): string[];
}
export { Facebook };
