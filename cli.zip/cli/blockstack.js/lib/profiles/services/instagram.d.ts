import { Service, CheerioModuleType } from './service';
import { AccountProofInfo } from '../profileProofs';
declare class Instagram extends Service {
    getBaseUrls(): string[];
    getProofUrl(proof: AccountProofInfo): string;
    normalizeUrl(proof: AccountProofInfo): string;
    shouldValidateIdentityInBody(): boolean;
    getProofIdentity(searchText: string, cheerio: CheerioModuleType): string;
    getProofStatement(searchText: string, cheerio: CheerioModuleType): string;
}
export { Instagram };
