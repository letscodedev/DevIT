import { Service, CheerioModuleType } from './service';
import { AccountProofInfo } from '../profileProofs';
declare class HackerNews extends Service {
    getBaseUrls(): string[];
    getProofUrl(proof: AccountProofInfo): string;
    normalizeUrl(_proof: AccountProofInfo): string;
    getProofStatement(searchText: string, cheerio: CheerioModuleType): string;
}
export { HackerNews };
