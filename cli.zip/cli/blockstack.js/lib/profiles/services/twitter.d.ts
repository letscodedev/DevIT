import { Service, CheerioModuleType } from './service';
import { AccountProofInfo } from '../profileProofs';
declare class Twitter extends Service {
    getBaseUrls(): string[];
    normalizeUrl(_proof: AccountProofInfo): string;
    getProofStatement(searchText: string, cheerio: CheerioModuleType): string;
    getProofUrl(proof: AccountProofInfo): string;
}
export { Twitter };
