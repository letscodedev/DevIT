import { CheerioModuleType } from './services/service';
/**
 * Represents a user profile
 *
 */
export declare class Profile {
    _profile: {
        [key: string]: any;
    };
    constructor(profile?: {});
    toJSON(): {
        [key: string]: any;
    };
    toToken(privateKey: string): string;
    static validateSchema(profile: any, strict?: boolean): any;
    static fromToken(token: string, publicKeyOrAddress?: string | null): Profile;
    static makeZoneFile(domainName: string, tokenFileURL: string): string;
    static validateProofs(domainName: string, cheerio: CheerioModuleType): Promise<any[]>;
}
