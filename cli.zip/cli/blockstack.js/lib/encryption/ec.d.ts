/// <reference types="node" />
import * as BN from 'bn.js';
/**
 * Controls how the encrypted data buffer will be encoded as a string in the JSON payload.
 * Options:
 *    `hex` -- the legacy default, file size increase 100% (2x).
 *    `base64` -- file size increased ~33%.
 * @ignore
 */
export declare type CipherTextEncoding = 'hex' | 'base64';
/**
 * @ignore
 */
export declare type CipherObject = {
    iv: string;
    ephemeralPK: string;
    cipherText: string;
    /** If undefined then hex encoding is used for the `cipherText` string. */
    cipherTextEncoding?: CipherTextEncoding;
    mac: string;
    wasString: boolean;
};
/**
 * @ignore
 */
export declare type SignedCipherObject = {
    /** Hex encoded DER signature (up to 144 chars) */
    signature: string;
    /** Hex encoded public key (66 char length) */
    publicKey: string;
    /** The stringified json of a `CipherObject` */
    cipherText: string;
};
/**
* @ignore
*/
export declare function aes256CbcEncrypt(iv: Buffer, key: Buffer, plaintext: Buffer): Promise<Buffer>;
/**
 * Hex encodes a 32-byte BN.js instance.
 * The result string is zero padded and always 64 characters in length.
 * @ignore
 */
export declare function getHexFromBN(bnInput: BN): string;
/**
 * Returns a big-endian encoded 32-byte BN.js instance.
 * The result Buffer is zero padded and always 32 bytes in length.
 * @ignore
 */
export declare function getBufferFromBN(bnInput: BN): Buffer;
/**
 * Get details about the JSON envelope size overhead for ciphertext payloads.
 * @ignore
 */
export declare function getCipherObjectWrapper(opts: {
    wasString: boolean;
    cipherTextEncoding: CipherTextEncoding;
}): {
    /** The stringified JSON string of an empty `CipherObject`. */
    payloadShell: string;
    /** Total string length of all the `CipherObject` values that always have constant lengths. */
    payloadValuesLength: number;
};
/**
 * Get details about the JSON envelope size overhead for signed ciphertext payloads.
 * @param payloadShell - The JSON stringified empty `CipherObject`
 * @ignore
 */
export declare function getSignedCipherObjectWrapper(payloadShell: string): {
    /** The stringified JSON string of an empty `SignedCipherObject`. */
    signedPayloadValuesLength: number;
    /** Total string length of all the `SignedCipherObject` values
     * that always have constant lengths */
    signedPayloadShell: string;
};
/**
 * Fast function that determines the final ASCII string byte length of the
 * JSON stringified ECIES encrypted payload.
 * @ignore
 */
export declare function eciesGetJsonStringLength(opts: {
    contentLength: number;
    wasString: boolean;
    sign: boolean;
    cipherTextEncoding: CipherTextEncoding;
}): number;
/**
 * Encrypt content to elliptic curve publicKey using ECIES
 * @param publicKey - secp256k1 public key hex string
 * @param content - content to encrypt
 * @return Object containing:
 *  iv (initialization vector, hex encoding),
 *  cipherText (cipher text either hex or base64 encoded),
 *  mac (message authentication code, hex encoded),
 *  ephemeral public key (hex encoded),
 *  wasString (boolean indicating with or not to return a buffer or string on decrypt)
 * @private
 * @ignore
 */
export declare function encryptECIES(publicKey: string, content: Buffer, wasString: boolean, cipherTextEncoding?: CipherTextEncoding): Promise<CipherObject>;
/**
 * Decrypt content encrypted using ECIES
 * @param {String} privateKey - secp256k1 private key hex string
 * @param {Object} cipherObject - object to decrypt, should contain:
 *  iv (initialization vector), cipherText (cipher text),
 *  mac (message authentication code), ephemeralPublicKey
 *  wasString (boolean indicating with or not to return a buffer or string on decrypt)
 * @return {Buffer} plaintext
 * @throws {FailedDecryptionError} if unable to decrypt
 * @private
 * @ignore
 */
export declare function decryptECIES(privateKey: string, cipherObject: CipherObject): Promise<Buffer | string>;
/**
 * Sign content using ECDSA
 *
 * @param {String} privateKey - secp256k1 private key hex string
 * @param {Object} content - content to sign
 * @return {Object} contains:
 * signature - Hex encoded DER signature
 * public key - Hex encoded private string taken from privateKey
 * @private
 * @ignore
 */
export declare function signECDSA(privateKey: string, content: string | Buffer): {
    publicKey: string;
    signature: string;
};
/**
 * Verify content using ECDSA
 * @param {String | Buffer} content - Content to verify was signed
 * @param {String} publicKey - secp256k1 private key hex string
 * @param {String} signature - Hex encoded DER signature
 * @return {Boolean} returns true when signature matches publickey + content, false if not
 * @private
 * @ignore
 */
export declare function verifyECDSA(content: string | ArrayBuffer | Buffer, publicKey: string, signature: string): boolean;
