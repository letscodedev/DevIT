/// <reference types="node" />
export interface Hmac {
    digest(key: Buffer, data: Buffer): Promise<Buffer>;
}
declare type NodeCryptoCreateHmac = typeof import('crypto').createHmac;
export declare class NodeCryptoHmacSha256 implements Hmac {
    createHmac: NodeCryptoCreateHmac;
    constructor(createHmac: NodeCryptoCreateHmac);
    digest(key: Buffer, data: Buffer): Promise<Buffer>;
}
export declare class WebCryptoHmacSha256 implements Hmac {
    subtleCrypto: SubtleCrypto;
    constructor(subtleCrypto: SubtleCrypto);
    digest(key: Buffer, data: Buffer): Promise<Buffer>;
}
export declare function createHmacSha256(): Promise<Hmac>;
export {};
