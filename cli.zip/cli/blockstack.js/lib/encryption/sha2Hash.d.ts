/// <reference types="node" />
declare type NodeCryptoCreateHash = typeof import('crypto').createHash;
export interface Sha2Hash {
    digest(data: Buffer, algorithm?: 'sha256' | 'sha512'): Promise<Buffer>;
}
export declare class NodeCryptoSha2Hash {
    createHash: NodeCryptoCreateHash;
    constructor(createHash: NodeCryptoCreateHash);
    digest(data: Buffer, algorithm?: string): Promise<Buffer>;
}
export declare class WebCryptoSha2Hash implements Sha2Hash {
    subtleCrypto: SubtleCrypto;
    constructor(subtleCrypto: SubtleCrypto);
    digest(data: Buffer, algorithm?: string): Promise<Buffer>;
}
export declare function createSha2Hash(): Promise<Sha2Hash>;
export declare function hashSha256Sync(data: Buffer): Buffer;
export declare function hashSha512Sync(data: Buffer): Buffer;
export {};
