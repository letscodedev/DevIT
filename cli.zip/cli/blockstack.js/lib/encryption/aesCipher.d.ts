/// <reference types="node" />
declare type NodeCryptoCreateCipher = typeof import('crypto').createCipheriv;
declare type NodeCryptoCreateDecipher = typeof import('crypto').createDecipheriv;
export declare type CipherAlgorithm = 'aes-256-cbc' | 'aes-128-cbc';
export interface AesCipher {
    encrypt(algorithm: CipherAlgorithm, key: Buffer, iv: Buffer, data: Buffer): Promise<Buffer>;
    decrypt(algorithm: CipherAlgorithm, key: Buffer, iv: Buffer, data: Buffer): Promise<Buffer>;
}
export declare class NodeCryptoAesCipher implements AesCipher {
    createCipher: NodeCryptoCreateCipher;
    createDecipher: NodeCryptoCreateDecipher;
    constructor(createCipher: NodeCryptoCreateCipher, createDecipher: NodeCryptoCreateDecipher);
    encrypt(algorithm: CipherAlgorithm, key: Buffer, iv: Buffer, data: Buffer): Promise<Buffer>;
    decrypt(algorithm: CipherAlgorithm, key: Buffer, iv: Buffer, data: Buffer): Promise<Buffer>;
}
export declare class WebCryptoAesCipher implements AesCipher {
    subtleCrypto: SubtleCrypto;
    constructor(subtleCrypto: SubtleCrypto);
    encrypt(algorithm: CipherAlgorithm, key: Buffer, iv: Buffer, data: Buffer): Promise<Buffer>;
    decrypt(algorithm: CipherAlgorithm, key: Buffer, iv: Buffer, data: Buffer): Promise<Buffer>;
}
export declare function createCipher(): Promise<AesCipher>;
export {};
