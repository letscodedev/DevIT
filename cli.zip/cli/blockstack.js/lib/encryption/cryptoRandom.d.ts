/// <reference types="node" />
import * as randombytes from 'randombytes';
export { randombytes as randomBytes };
/** Optional function to generate cryptographically secure random bytes */
export declare type GetRandomBytes = (count: number) => Buffer;
