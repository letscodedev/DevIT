/// <reference types="node" />
declare type NodeCryptoCreateHash = typeof import('crypto').createHash;
export interface Ripemd160Digest {
    digest(data: Buffer): Buffer;
}
export declare class Ripemd160PolyfillDigest implements Ripemd160Digest {
    digest(data: Buffer): Buffer;
}
export declare class NodeCryptoRipemd160Digest implements Ripemd160Digest {
    nodeCryptoCreateHash: NodeCryptoCreateHash;
    constructor(nodeCryptoCreateHash: NodeCryptoCreateHash);
    digest(data: Buffer): Buffer;
}
export declare function createHashRipemd160(): Ripemd160PolyfillDigest | NodeCryptoRipemd160Digest;
export declare function hashRipemd160(data: Buffer): Buffer;
export {};
