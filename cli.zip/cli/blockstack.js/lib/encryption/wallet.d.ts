/// <reference types="node" />
import { GetRandomBytes } from './cryptoRandom';
import { TriplesecDecryptSignature } from './cryptoUtils';
/**
 * Encrypt a raw mnemonic phrase to be password protected
 * @param {string} phrase - Raw mnemonic phrase
 * @param {string} password - Password to encrypt mnemonic with
 * @return {Promise<Buffer>} The encrypted phrase
 * @private
 * @ignore
 * */
export declare function encryptMnemonic(phrase: string, password: string, opts?: {
    getRandomBytes?: GetRandomBytes;
}): Promise<Buffer>;
/**
 * Decrypt an encrypted mnemonic phrase with a password.
 * Legacy triplesec encrypted payloads are also supported.
 * @param data - Buffer or hex-encoded string of the encrypted mnemonic
 * @param password - Password for data
 * @return the raw mnemonic phrase
 * @private
 * @ignore
 */
export declare function decryptMnemonic(data: (string | Buffer), password: string, triplesecDecrypt: TriplesecDecryptSignature): Promise<string>;
