/// <reference types="node" />
export declare type Pbkdf2Digests = 'sha512' | 'sha256';
export interface Pbkdf2 {
    derive(password: string, salt: Buffer, iterations: number, keyLength: number, digest: Pbkdf2Digests): Promise<Buffer>;
}
declare type NodePbkdf2Fn = typeof import('crypto').pbkdf2;
export declare class NodeCryptoPbkdf2 implements Pbkdf2 {
    nodePbkdf2: NodePbkdf2Fn;
    constructor(nodePbkdf2: NodePbkdf2Fn);
    derive(password: string, salt: Buffer, iterations: number, keyLength: number, digest: Pbkdf2Digests): Promise<Buffer>;
}
export declare class WebCryptoPbkdf2 implements Pbkdf2 {
    subtleCrypto: SubtleCrypto;
    constructor(subtleCrypto: SubtleCrypto);
    derive(password: string, salt: Buffer, iterations: number, keyLength: number, digest: Pbkdf2Digests): Promise<Buffer>;
}
export declare class WebCryptoPartialPbkdf2 implements Pbkdf2 {
    subtleCrypto: SubtleCrypto;
    constructor(subtleCrypto: SubtleCrypto);
    derive(password: string, salt: Buffer, iterations: number, keyLength: number, digest: Pbkdf2Digests): Promise<Buffer>;
}
export declare function createPbkdf2(): Promise<Pbkdf2>;
export {};
