/// <reference types="node" />
export declare function isSubtleCryptoAvailable(): boolean;
export declare function isNodeCryptoAvailable<T>(withFeature: (nodeCrypto: typeof import('crypto')) => boolean | T): false | T;
export declare const NO_CRYPTO_LIB = "Crypto lib not found. Either the WebCrypto \"crypto.subtle\" or Node.js \"crypto\" module must be available.";
export declare type TriplesecDecryptSignature = (arg: {
    data: Buffer;
    key: Buffer;
}, cb: (err: Error | null, buff: Buffer | null) => void) => void;
export interface WebCryptoLib {
    lib: SubtleCrypto;
    name: 'subtleCrypto';
}
export interface NodeCryptoLib {
    lib: typeof import('crypto');
    name: 'nodeCrypto';
}
export declare function getCryptoLib(): Promise<WebCryptoLib | NodeCryptoLib>;
