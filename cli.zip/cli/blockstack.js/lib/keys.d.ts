/// <reference types="node" />
import { ECPair } from 'bitcoinjs-lib';
/**
 *
 * @param numberOfBytes
 *
 * @ignore
 */
export declare function getEntropy(arg: number): Buffer;
/**
* @ignore
*/
export declare function makeECPrivateKey(): string;
/**
* @ignore
*/
export declare function publicKeyToAddress(publicKey: string | Buffer): string;
/**
* @ignore
*/
export declare function getPublicKeyFromPrivate(privateKey: string | Buffer): string;
/**
 * Time
 * @private
 * @ignore
 */
export declare function hexStringToECPair(skHex: string): ECPair.ECPairInterface;
/**
 *
 * @ignore
 */
export declare function ecPairToHexString(secretKey: ECPair.ECPairInterface): string;
/**
 * Creates a bitcoin address string from an ECPair
 * @private
 * @ignore
 */
export declare function ecPairToAddress(keyPair: ECPair.ECPairInterface): string;
