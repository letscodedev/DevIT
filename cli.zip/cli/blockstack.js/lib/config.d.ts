/**
* @ignore
*/
declare const config: {
    network: import("./network").BlockstackNetwork;
    logLevel: string;
};
export { config };
