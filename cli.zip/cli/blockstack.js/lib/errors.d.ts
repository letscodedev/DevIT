/**
* @ignore
*/
export declare const ERROR_CODES: {
    MISSING_PARAMETER: string;
    REMOTE_SERVICE_ERROR: string;
    INVALID_STATE: string;
    NO_SESSION_DATA: string;
    DOES_NOT_EXIST: string;
    FAILED_DECRYPTION_ERROR: string;
    INVALID_DID_ERROR: string;
    NOT_ENOUGH_FUNDS_ERROR: string;
    INVALID_AMOUNT_ERROR: string;
    LOGIN_FAILED_ERROR: string;
    SIGNATURE_VERIFICATION_ERROR: string;
    CONFLICT_ERROR: string;
    NOT_ENOUGH_PROOF_ERROR: string;
    BAD_PATH_ERROR: string;
    VALIDATION_ERROR: string;
    PAYLOAD_TOO_LARGE_ERROR: string;
    PRECONDITION_FAILED_ERROR: string;
    UNKNOWN: string;
};
/**
* @ignore
*/
declare type ErrorData = {
    code: string;
    parameter?: string;
    message: string;
};
/**
* @ignore
*/
export declare class BlockstackError extends Error {
    message: string;
    code: string;
    parameter?: string;
    constructor(error: ErrorData);
    toString(): string;
}
/**
* @ignore
*/
export declare class InvalidParameterError extends BlockstackError {
    constructor(parameter: string, message?: string);
}
/**
* @ignore
*/
export declare class MissingParameterError extends BlockstackError {
    constructor(parameter: string, message?: string);
}
/**
* @ignore
*/
export declare class RemoteServiceError extends BlockstackError {
    response: Response;
    constructor(response: Response, message?: string);
}
/**
* @ignore
*/
export declare class InvalidDIDError extends BlockstackError {
    constructor(message?: string);
}
/**
* @ignore
*/
export declare class NotEnoughFundsError extends BlockstackError {
    leftToFund: number;
    constructor(leftToFund: number);
}
/**
* @ignore
*/
export declare class InvalidAmountError extends BlockstackError {
    fees: number;
    specifiedAmount: number;
    constructor(fees: number, specifiedAmount: number);
}
/**
* @ignore
*/
export declare class LoginFailedError extends BlockstackError {
    constructor(reason: string);
}
/**
* @ignore
*/
export declare class SignatureVerificationError extends BlockstackError {
    constructor(reason: string);
}
/**
* @ignore
*/
export declare class FailedDecryptionError extends BlockstackError {
    constructor(message?: string);
}
/**
* @ignore
*/
export declare class InvalidStateError extends BlockstackError {
    constructor(message: string);
}
/**
* @ignore
*/
export declare class NoSessionDataError extends BlockstackError {
    constructor(message: string);
}
/**
* @ignore
*/
export interface GaiaHubErrorResponse {
    status: number;
    statusText: string;
    body?: string | any;
}
export interface HubErrorDetails {
    message?: string;
    statusCode: number;
    statusText: string;
    [prop: string]: any;
}
/**
* @ignore
*/
export declare class GaiaHubError extends BlockstackError {
    hubError: HubErrorDetails;
    constructor(error: ErrorData, response: GaiaHubErrorResponse);
}
/**
* @ignore
*/
export declare class DoesNotExist extends GaiaHubError {
    constructor(message: string, response: GaiaHubErrorResponse);
}
/**
* @ignore
*/
export declare class ConflictError extends GaiaHubError {
    constructor(message: string, response: GaiaHubErrorResponse);
}
/**
* @ignore
*/
export declare class NotEnoughProofError extends GaiaHubError {
    constructor(message: string, response: GaiaHubErrorResponse);
}
/**
* @ignore
*/
export declare class BadPathError extends GaiaHubError {
    constructor(message: string, response: GaiaHubErrorResponse);
}
/**
* @ignore
*/
export declare class ValidationError extends GaiaHubError {
    constructor(message: string, response: GaiaHubErrorResponse);
}
/**
 * @ignore
 */
export declare class PayloadTooLargeError extends GaiaHubError {
    /** Can be `null` when an oversized payload is detected client-side. */
    hubError: HubErrorDetails;
    maxUploadByteSize: number;
    constructor(message: string, response: GaiaHubErrorResponse, maxUploadByteSize: number);
}
/**
 * @ignore
 */
export declare class PreconditionFailedError extends GaiaHubError {
    constructor(message: string, response: GaiaHubErrorResponse);
}
export {};
