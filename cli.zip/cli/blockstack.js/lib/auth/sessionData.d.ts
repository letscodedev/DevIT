import { GaiaHubConfig } from '../storage/hub';
import { UserData } from './authApp';
export interface SessionOptions {
    coreNode?: string;
    userData?: UserData;
    transitKey?: string;
    localStorageKey?: string;
    storeOptions?: {
        localStorageKey?: string;
    };
}
/**
 * @ignore
 */
export declare class SessionData {
    version: string;
    transitKey?: string;
    userData?: UserData;
    constructor(options: SessionOptions);
    getGaiaHubConfig(): GaiaHubConfig;
    setGaiaHubConfig(config: GaiaHubConfig): void;
    static fromJSON(json: any): SessionData;
    toString(): string;
}
