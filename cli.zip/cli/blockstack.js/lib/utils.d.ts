/**
 *  @ignore
 */
export declare const BLOCKSTACK_HANDLER = "blockstack";
/**
 * Time
 * @private
 * @ignore
 */
export declare function nextYear(): Date;
/**
 * Time
 * @private
 * @ignore
 */
export declare function nextMonth(): Date;
/**
 * Time
 * @private
 * @ignore
 */
export declare function nextHour(): Date;
/**
 * Converts megabytes to bytes. Returns 0 if the input is not a finite number.
 * @ignore
 */
export declare function megabytesToBytes(megabytes: number): number;
/**
 * Calculate the AES-CBC ciphertext output byte length a given input length.
 * AES has a fixed block size of 16-bytes regardless key size.
 * @ignore
 */
export declare function getAesCbcOutputLength(inputByteLength: number): number;
/**
 * Calculate the base64 encoded string length for a given input length.
 * This is equivalent to the byte length when the string is ASCII or UTF8-8
 * encoded.
 * @param number
 */
export declare function getBase64OutputLength(inputByteLength: number): number;
/**
 * Query Strings
 * @private
 * @ignore
 */
export declare function updateQueryStringParameter(uri: string, key: string, value: string): string;
/**
 * Versioning
 * @param {string} v1 - the left half of the version inequality
 * @param {string} v2 - right half of the version inequality
 * @returns {bool} iff v1 >= v2
 * @private
 * @ignore
 */
export declare function isLaterVersion(v1: string, v2: string): boolean;
/**
 * UUIDs
 * @private
 * @ignore
 */
export declare function makeUUID4(): string;
/**
 * Checks if both urls pass the same origin check & are absolute
 * @param  {[type]}  uri1 first uri to check
 * @param  {[type]}  uri2 second uri to check
 * @return {Boolean} true if they pass the same origin check
 * @private
 * @ignore
 */
export declare function isSameOriginAbsoluteUrl(uri1: string, uri2: string): boolean;
/**
 * Returns the global scope `Window`, `WorkerGlobalScope`, or `NodeJS.Global` if available in the
 * currently executing environment.
 * @see https://developer.mozilla.org/en-US/docs/Web/API/Window/self
 * @see https://developer.mozilla.org/en-US/docs/Web/API/WorkerGlobalScope/self
 * @see https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope
 *
 * This could be switched to `globalThis` once it is standardized and widely available.
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/globalThis
 * @ignore
 */
export declare function getGlobalScope(): Window;
interface GetGlobalObjectOptions {
    /**
     * Throw an error if the object is not found.
     * @default false
     */
    throwIfUnavailable?: boolean;
    /**
     * Additional information to include in an error if thrown.
     */
    usageDesc?: string;
    /**
     * If the object is not found, return an new empty object instead of undefined.
     * Requires [[throwIfUnavailable]] to be falsey.
     * @default false
     */
    returnEmptyObject?: boolean;
}
/**
 * Returns an object from the global scope (`Window` or `WorkerGlobalScope`) if it
 * is available within the currently executing environment.
 * When executing within the Node.js runtime these APIs are unavailable and will be
 * `undefined` unless the API is provided via polyfill.
 * @see https://developer.mozilla.org/en-US/docs/Web/API/Window/self
 * @ignore
 */
export declare function getGlobalObject<K extends Extract<keyof Window, string>>(name: K, { throwIfUnavailable, usageDesc, returnEmptyObject }?: GetGlobalObjectOptions): Window[K];
/**
 * Returns a specified subset of objects from the global scope (`Window` or `WorkerGlobalScope`)
 * if they are available within the currently executing environment.
 * When executing within the Node.js runtime these APIs are unavailable will be `undefined`
 * unless the API is provided via polyfill.
 * @see https://developer.mozilla.org/en-US/docs/Web/API/Window/self
 * @ignore
 */
export declare function getGlobalObjects<K extends Extract<keyof Window, string>>(names: K[], { throwIfUnavailable, usageDesc, returnEmptyObject }?: GetGlobalObjectOptions): Pick<Window, K>;
/**
 * Returns a BlockstackError correlating to the given HTTP response,
 * with the provided errorMsg. Throws if the HTTP response is 'ok'.
 */
export declare function getBlockstackErrorFromResponse(response: Response, errorMsg: string, hubConfig: import('./storage/hub').GaiaHubConfig | null): Promise<Error>;
export {};
