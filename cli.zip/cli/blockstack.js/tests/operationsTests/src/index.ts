import { runIntegrationTests } from './operationsTests'

runIntegrationTests()
