const EllipticCurve = require('elliptic').ec
const fs = require('fs');
const fse = require('fs-extra');
const common = require("./common")
const axios = require('axios');
const encryption = require("./blockstack.js/lib/encryption")
const getUserAppFileUrl = require("./blockstack.js/lib").getUserAppFileUrl
const FileContentLoader = require("./blockstack.js/lib/storage").FileContentLoader
const getPublicKeyFromPrivate = require("./blockstack.js/lib/keys").getPublicKeyFromPrivate
const encryptContent = require("./blockstack.js/lib/storage").encryptContent
const uploadToGaiaHub = require("./blockstack.js/lib/storage/hub").uploadToGaiaHub
const deleteFromGaiaHub = require("./blockstack.js/lib/storage/hub").deleteFromGaiaHub
const glob = require("glob")

async function pull() {
    try {
        if (islogin()) {
            let data
            try {
                data = fs.readFileSync("project.json", 'utf8')
            } catch (e) {
                console.log("Init Project First!")
                return
            }
            data = JSON.parse(data)
            if (data.name && data.sharedkey) {
                let project_name = (data.name).split("@")[0]
                let manager_id = (data.name).split("@")[1]
                let master_file = await getFile(project_name + ".json", false, manager_id)
                let local_file = await getFile(data.name + ".json", false)
                local_file = await common.decrypt(local_file, data.sharedkey)
                master_file = await common.decrypt(master_file, data.sharedkey)
                master_file = JSON.parse(master_file)
                local_file = JSON.parse(local_file)
                if (local_file.commit >= master_file.commit) {
                    console.log("Your LocalSpace Already Up-to-date!")
                    return
                }

                let master_fs = await getFile(project_name + "/fs.json", false, manager_id)
                master_fs = await common.decrypt(master_fs, data.sharedkey)
                master_fs = JSON.parse(master_fs)

                glob('./**/*.*', function (err, res) {
                    (async () => {

                        let changes = false
                        for (let file in res) {
                            file = res[file].substr(2)
                            if (file == "fs.json" || file == "project.json") {
                                continue;
                            }
                            if (master_fs.hasOwnProperty(file)) {
                                let file_data = fs.readFileSync("fs.json", 'utf8')
                                if (master_fs[file] != await common.checksum(file_data)) {

                                    file_data = await getFile(project_name + "/" + file, false, data.manager_id)
                                    await putFile(data.name + "/" + file, file_data)
                                    file_data = await common.decrypt(file_data, data.sharedkey)
                                    changes = true
                                    fs.writeFileSync(file, file_data, 'utf-8');
                                }
                            } else {
                                //delet from gaia
                                changes = true
                                await deletFile(data.name + "/" + file)
                                fs.unlink(file, function (err) { })

                            }

                        }
                        if (changes) {
                            fs.writeFileSync("fs.json", JSON.stringify(master_fs), 'utf-8');
                            master_fs = await common.encrypt(JSON.stringify(master_fs), data.sharedkey)
                            await putFile(data.name + "/fs.json", master_fs)
                            master_file = await common.encrypt(JSON.stringify(master_file), data.sharedkey)
                            await putFile(data.name + ".json", master_file)
                            console.log("Workspace Pulled Sucessfully!")
                        }
                    })()
                })
            } else {
                console.log("Init Project First!")
            }
        } else {
            console.log("Login First!")
        }
    } catch (e) { console.log(e) }
}

async function load() {
    try {

        if (islogin()) {
            let data
            try {
                data = fs.readFileSync("project.json", 'utf8')
            } catch (e) {
                console.log("Init Project First!")
                return
            }
            data = JSON.parse(data)
            if (data.name && data.sharedkey) {
                let project_name = (data.name).split("@")[0]
                let manager_id = data.manager_id
                let master_file = await getFile(project_name + ".json", false, manager_id)
                let local_file = await getFile(data.name + ".json", false)
                local_file = await common.decrypt(local_file, data.sharedkey)
                master_file = await common.decrypt(master_file, data.sharedkey)
                master_file = JSON.parse(master_file)
                local_file = JSON.parse(local_file)
                if (local_file.commit < master_file.commit) {
                    console.log("Changes Ocuured On Master Space, Pull First!")
                    return
                }
                let args = process.argv
                let local_fs = fs.readFileSync("fs.json", 'utf8')
                local_fs = JSON.parse(local_fs)
                if (args[3] == "flush") {
                    local_fs = {}
                }
                glob('./**/*.*', function (err, res) {
                    (async () => {

                        let changes = false
                        for (let file in res) {
                            file = res[file].substr(2)
                            if (file == "fs.json" || file == "project.json") {
                                continue
                            }
                            if (!local_fs.hasOwnProperty(file)) {
                                let file_data = fs.readFileSync(file, 'utf8')
                                local_fs[file] = await common.checksum(file_data)
                                changes = true
                                file_data = await common.encrypt(file_data, data.sharedkey)
                                await putFile(data.name + "/" + file, file_data)
                            } else {
                                let file_data = fs.readFileSync(file, 'utf8')
                                if (local_fs[file] != (await common.checksum(file_data))) {
                                    local_fs[file] = await common.checksum(file_data)
                                    changes = true
                                    file_data = await common.encrypt(file_data, data.sharedkey)
                                    await putFile(data.name + "/" + file, file_data)
                                }
                            }

                        }
                        for (let file in local_fs) {
                            if (!fs.existsSync("./" + file)) {
                                await deletFile(data.name + "/" + file)
                                delete local_fs[file]
                                changes = true
                            }
                        }
                        if (changes) {
                            local_file.commit = Date.now()
                            local_file = await common.encrypt(JSON.stringify(local_file), data.sharedkey)
                            fs.writeFileSync("fs.json", JSON.stringify(local_fs), 'utf-8');
                            local_fs = await common.encrypt(JSON.stringify(local_fs), data.sharedkey)
                            await putFile(data.name + ".json", local_file)
                            await putFile(data.name + "/fs.json", local_fs)
                            console.log("Workspace Loaded On Gaia Sucessfully!")
                            return
                        }
                        console.log("No Changes")
                    })()
                });
            } else {
                console.log("Init Project First!")
            }
        } else {
            console.log("Login First!")
        }
    } catch (e) {
        console.log(e)

    }
}


async function putFile(path, content, encrypt) {
    try {
        let usersession = getUserSession()
        let contentLoader = new FileContentLoader(content)
        let contentData = contentLoader.content
        let contentType = contentLoader.contentType
        if (encrypt) {
            contentData = await contentLoader.load()
            contentData = await encryptContent(contentData, { publicKey: getPublicKeyFromPrivate(usersession.appPrivateKey) })
            contentType = 'application/json'
        }
        await uploadToGaiaHub(path, contentData, usersession.gaiaHubConfig, contentType, false)
    } catch (e) {
        console.log(e)
    }
}

async function deletFile(filename) {
    try {
        let usersession = getUserSession()
        await deleteFromGaiaHub(filename, usersession.gaiaHubConfig)
    } catch (e) {
        console.log(e)
    }

}

async function getFile(filename, decrypt, username) {
    //get gaia hub url
    //`${hubConfig.url_prefix}${hubConfig.address}/${filename}`
    try {
        let usersession = getUserSession()
        let fileUrl;
        if (!username) {
            fileUrl = usersession.gaiaHubConfig.url_prefix + usersession.gaiaHubConfig.address + "/" + filename
        } else {
            //${this.blockstackAPIUrl}/v1/names/${fullyQualifiedName}`
            fileUrl = await getUserAppFileUrl(filename, username, "https://devit-7cd11.web.app")
        }
        let fetchedData = await axios.get(fileUrl)
        if (decrypt) {

            return await encryption.decryptECIES(usersession.appPrivateKey, fetchedData.data)
        }
        return fetchedData.data
    } catch (e) {
        //console.log("Error While Fetching File, Maybe User Not Found Or File is Missing");
        return null

    }

}



async function init() {
    try {
        if (!islogin()) {
            console.log("Please Login First!")
            return
        }
        let arguments = process.argv
        let project_name = arguments[3]
        let manager_id
        if (!project_name) {
            console.log("Project Name Missing In Parameter!")
            return
        }
        let project_data
        try {
            project_data = fs.readFileSync("project.json", 'utf8')
            project_data = JSON.parse(project_data)
            if (project_data.sharedkey) {
                console.log("Project Already Init")
                return
            }
        } catch (e) {

        }

        project_data = (await getFile("joined_project.json", true))

        if (!project_data) {
            console.log("You Not Joined Project!")
            return
        }
        project_data = JSON.parse(project_data)
        for (let project in project_data.my_projects) {
            if (project.split("@")[0] == project_name) {
                manager_id = project.split("@")[1]
                break
            }
        }
        if (!manager_id) {
            console.log("YOu Not Joined Project!")
            return
        }
        let project_fs = (await getFile(project_name + "/fs.json", false, manager_id))
        project_fs = await common.decrypt(project_fs, project_data.my_projects[project_name + "@" + manager_id].sharedkey)
        project_fs = JSON.parse(project_fs)
        for (let file in project_fs) {
            let file_data = (await getFile(project_name + "/" + file, false, manager_id))
            file_data = await common.decrypt(file_data, project_data.my_projects[project_name + "@" + manager_id].sharedkey)
            fse.outputFileSync(file, file_data)
            // fs.writeFileSync( file, file_data, 'utf-8');
        }
        fs.writeFileSync('fs.json', JSON.stringify(project_fs), 'utf-8');
        project_data.my_projects[project_name + "@" + manager_id].name = project_name + "@" + manager_id
        fs.writeFileSync('project.json', JSON.stringify(project_data.my_projects[project_name + "@" + manager_id]), 'utf-8');
        console.log("Project Init Sucessfully!")
    } catch (e) {
        console.log(e)
        console.log("error")
    }


}


function getUserSession() {
    try {
        let coreDir = __dirname
        let data = fs.readFileSync(coreDir + "/session.json", 'utf8')
        data = JSON.parse(data)
        if (data.appPrivateKey && data.username) {
            return data
        } else {
            console.log("Please Login First!")
            return
        }
    } catch (e) {
        console.log("Please Login First!")
        return
    }
}



function islogin() {
    try {
        let coreDir = __dirname
        let data = fs.readFileSync(coreDir + "/session.json", 'utf8')
        data = JSON.parse(data)
        if (data.appPrivateKey && data.username) {
            return true
        } else {
            return false
        }
    } catch (e) {
        return false
    }
}


function createSession() {
    let arguments = process.argv
    let configKey = arguments[3]
    let config_file = "cli-config.txt";
    if (!arguments[2]) {
        console.log("Config Key Missing in Parameters!")
        return
    }
    if (arguments[4]) {
        config_file = arguments[4]
    }
    fs.readFile(config_file, function (err, data) {
        if (err) {
            console.log("Config File Not Found!")
            return
        }
        (async () => {
            let coreDir = __dirname
            let session_data = await common.decrypt(data.toString(), configKey)
            let session_data_json = JSON.parse(session_data)
            if (session_data_json.appPrivateKey && session_data_json.username) {
                fs.writeFile(coreDir + "/session.json", session_data, function (err) {
                    if (err) {
                        console.log(err)
                        console.log("Unable To Login!")
                        return
                    }
                    console.log('Login Sucessfully!');
                });
            }
        })();
    })
}


function login() {

    try {
        let coreDir = __dirname
        fs.readFile(coreDir + "/session.json", function (err, data) {
            if (err) {
                createSession()
            } else {
                data = JSON.parse(data.toString())
                if (data.appPrivateKey && data.username) {
                    console.log("Already LoggedIn!")
                }
            }
        });

    } catch (e) {
        createSession()
    }

}

async function test() {
    await load()
    //console.log((await getFile("soulxx.js", true)).toString())
    //console.log((await common.checksum("dsfhndskjfkdsbfkdsbfkdsjbfksbfkjdsbfksdbfkdjbsfkjbdkjfbdksb")))
}

function logout() {
    let coreDir = __dirname
    fs.unlink(coreDir + "/session.json", function (err) {
        if (!err) {
            console.log("Logout sucessfully!")
        } else {
            console.log("Failed To Logout or Already Logged In!")
        }
    })
}
(async () => {
    let args = process.argv
    if (args[2] == "login") {
        login()
    } else if (args[2] == "init") {
        await init()
    } else if (args[2] == "logout") {
        logout()
    } else if (args[2] == "pull") {
        await pull()
    } else if (args[2] == "push") {
        await load()
    }
    else if (args[2] == "test") {
        test()
    }
})()